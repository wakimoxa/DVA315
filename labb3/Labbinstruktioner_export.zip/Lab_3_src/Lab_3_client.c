/*
 ============================================================================
 Name        : Lab_3_client.c
 Author      : Jakob Danielsson
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int main(void)
{
	printf("Hello lab 3!");
	return EXIT_SUCCESS;
}
